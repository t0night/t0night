var group___object_buffers =
[
    [ "canObjBufAllocate", "group___object_buffers.html#gaa189a35c78004d037eed4bd0c2bfa3ee", null ],
    [ "canObjBufDisable", "group___object_buffers.html#gab1238b563ecf4523092ebe561ece87ea", null ],
    [ "canObjBufEnable", "group___object_buffers.html#ga1ff3e82f6d0e9795a831e22183c6e7ec", null ],
    [ "canObjBufFree", "group___object_buffers.html#ga7353b3671b897e1f33b88f9084857382", null ],
    [ "canObjBufFreeAll", "group___object_buffers.html#gab299ecf20aa368b8ee253ba9610dff3b", null ],
    [ "canObjBufSendBurst", "group___object_buffers.html#gae3e27cd339700f26897648895e1b37a0", null ],
    [ "canObjBufSetFilter", "group___object_buffers.html#gaccca9d669c981e910c1805614ee40e72", null ],
    [ "canObjBufSetFlags", "group___object_buffers.html#ga9369c2f47886d9f815fe5513d6f5b60b", null ],
    [ "canObjBufSetMsgCount", "group___object_buffers.html#ga769ce97c3b7f3a8e246f872d7dbafe54", null ],
    [ "canObjBufSetPeriod", "group___object_buffers.html#gaa23baa37921bf089d9123eb97f32541b", null ],
    [ "canObjBufWrite", "group___object_buffers.html#gad72611f11b4947c96c8d0b50f59b2173", null ]
];